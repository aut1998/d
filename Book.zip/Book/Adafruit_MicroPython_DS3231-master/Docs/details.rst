
.. automodule:: adafruit_ds3231
   :members:

