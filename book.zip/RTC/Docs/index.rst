.. Adafruit's DS3231 RTC Library documentation master file, created by
   sphinx-quickstart on Fri Nov 11 21:37:36 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Adafruit's DS3231 RTC Library's documentation!
=========================================================

Contents:

.. toctree::
   :maxdepth: 2

   introduction
   details


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

